
import authServices from "../services/auth.services.js";
import aiServices from "../services/ai.services.js";
import productServices from "../services/product.services.js";
import { dataResponse, errorResponse } from "../utils/responses.js";
import createError from "http-errors";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

const userController = {
  async userRegister(req, res, next) {
    try {
      const { name, email, password, ...userData } = req.body;
      const result = await authServices.userRegister( name, email, password, userData);
      return res.status(201).send(dataResponse("User registered successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async userLogin(req, res, next) {
    try {
      const { email, password } = req.body;
      const result = await authServices.userLogin(email, password);
      return res.status(200).send(dataResponse("Login successful", result));
    } catch (error) {
      next(error);
    }
  },

  async registerWithProvider(req, res, next) {
    try {
      const { firebaseToken, type, ...userData } = req.body;
      const result = await authServices.registerWithProvider(firebaseToken, type, userData);
      return res.status(201).send(dataResponse("User registered successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async loginWithProvider(req, res, next) {
    try {
      const { firebaseToken, type } = req.body;
      const result = await authServices.loginWithProvider(firebaseToken, type);
      return res.status(200).send(dataResponse("Login successful", result));
    } catch (error) {
      next(error);
    }
  },
  async createUserData(req, res, next) {
    try {
      const userId = req.user; 
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }

      const { gender, age, weight } = req.body;

      // Validate input data
      if (!gender && !age && !weight) {
        throw createError(400, "At least one field must be provided");
      }

      // Check if user exists
      const existingUser = await prisma.user.findUnique({
        where: { id: userId }
      });

      if (!existingUser) {
        throw createError(404, "User not found");
      }

      // Update user data
      const updatedUser = await prisma.user.update({
        where: { id: userId },
        data: {
          gender: gender || null,
          age: age || null,
          weight: weight || null
        },
        select: {
          id: true,
          email: true,
          name: true,
          role: true,
          userImage: true,
          gender: true,
          age: true,
          weight: true,
          createdAt: true,
          updatedAt: true
        }
      });

      return res.status(200).send(dataResponse("User data created successfully", { user: updatedUser }));
    } catch (error) {
      next(error);
    }
  },
  async getMyProfile(req, res, next) {
    try {
      const userId = req.user; // Assuming JWT middleware sets req.user
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const result = await authServices.getMyProfile(userId);
      return res.status(200).send(dataResponse("Profile fetched successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async updateProfile(req, res, next) {
    try {
      const userId = req.user; // Assuming JWT middleware sets req.user
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const result = await authServices.updateProfile(userId, req.body);
      return res.status(200).send(dataResponse("Profile updated successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async requestPasswordReset(req, res, next) {
    try {
      const { email } = req.body;
      const result = await authServices.requestPasswordReset(email);
      return res.status(200).send(dataResponse("Password reset OTP sent successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async verifyResetOtp(req, res, next) {
    try {
      const { email, otp } = req.body;
      const result = await authServices.verifyResetOtp(email, otp);
      return res.status(200).send(dataResponse("OTP verified successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async resendResetOtp(req, res, next) {
    try {
      const { email } = req.body;
      const result = await authServices.resendResetOtp(email);
      return res.status(200).send(dataResponse("OTP resent successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async setNewPassword(req, res, next) {
    try {
      const { email, newPassword } = req.body;
      const result = await authServices.setNewPassword(email, newPassword);
      return res.status(200).send(dataResponse("Password updated successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async getAIAnalysis(req, res, next) {
    try {
      const { barcode } = req.body;
      const userId = req.user; 
      console.log("🚀 ~ getAIAnalysis ~ barcode:", barcode)
      console.log("🚀 ~ getAIAnalysis ~ userId:", userId)
      
      const result = await aiServices.analyzeFood(barcode, userId);
      return res.status(200).send(dataResponse("Detail fetched successfully", result));
    } catch (error) {
      next(error);
    }
  },



  async analyzeCustomProduct(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const { productName, companyName, imageURL } = req.body;
      if (!productName || !companyName) {
        return res.status(400).send(errorResponse("productName and companyName are required"));
      }
      const result = await aiServices.analyzeProductManual({ productName, companyName, imageURL }, userId);
      return res.status(200).send(dataResponse("Custom product analyzed successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async getProduct(req, res, next) {
    const userId = req.user;
    try {
      const { barcode } = req.body;
      if (!barcode) {
        return res.status(400).send(errorResponse("Barcode is required"));
      }

      const result = await productServices.getProductData(barcode, userId);
      return res.status(200).send(dataResponse("Product data fetched successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async getProductAlternatives(req, res, next) {
    try {
      const { barcode, comparedToCategory, score, fallbackCategory } = req.body;
      if (!barcode) {
        return res.status(400).send(errorResponse("Barcode is required"));
      }
      if (!comparedToCategory || typeof comparedToCategory !== 'string') {
        return res.status(400).send(errorResponse("comparedToCategory is required and must be a string"));
      }
      if (score === undefined || score === null) {
        return res.status(400).send(errorResponse("score is required"));
      }
      const numericScore = Number(score);
      if (isNaN(numericScore) || numericScore < 0 || numericScore > 10) {
        return res.status(400).send(errorResponse("score must be a number between 0 and 10"));
      }

      const resolvedFallback = (fallbackCategory && typeof fallbackCategory === 'string') ? fallbackCategory : null;
      const result = await productServices.getProductAlternatives(barcode, comparedToCategory, numericScore, resolvedFallback);
      return res.status(200).send(dataResponse("Alternatives fetched successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async searchProducts(req, res, next) {
    try {
      const { q, page = '1', limit = '5' } = req.query;
      if (!q || q.trim().length === 0) {
        return res.status(400).send(errorResponse("Search term (q) is required"));
      }
      console.log("🚀 ~ searchProducts ~ searchTerm:", q);
      
      const result = await productServices.searchProducts(q, { page, limit });
      return res.status(200).send(dataResponse("Products searched successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async getMyHistory(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const { page = '1', limit = '10', q = '' } = req.query;
      const result = await productServices.getMyHistory(userId, { page, limit, search: q });
      return res.status(200).send(dataResponse("History fetched successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async deleteMyHistory(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const { id } = req.params;
      const result = await productServices.deleteMyHistory(userId, id);
      return res.status(200).send(dataResponse("History deleted successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async getMyCart(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const result = await productServices.getMyCart(userId);
      return res.status(200).send(dataResponse("Cart fetched successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async addToCart(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const productData = req.body;
      
      if (!productData.barcode || !productData.productName) {
        return res.status(400).send(errorResponse("Product data is required (barcode and productName)"));
      }

      const result = await productServices.addToCart(userId, productData);
      return res.status(200).send(dataResponse("Product added to cart successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async deleteFromCart(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const { id } = req.params;
      const result = await productServices.deleteFromCart(userId, id);
      return res.status(200).send(dataResponse("Item removed from cart successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async deleteCompleteCart(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const result = await productServices.deleteCompleteCart(userId);
      return res.status(200).send(dataResponse("Cart cleared successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async deleteAllMyHistory(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const result = await productServices.deleteAllMyHistory(userId);
      return res.status(200).send(dataResponse("All history deleted successfully", result));
    } catch (error) {
      next(error);
    }
  },

  async deleteMyAccount(req, res, next) {
    try {
      const userId = req.user;
      if (!userId) {
        return res.status(401).send(errorResponse("Authentication required"));
      }
      const result = await authServices.deleteMyAccount(userId);
      return res.status(200).send(dataResponse("Account deleted successfully", result));
    } catch (error) {
      next(error);
    }
  },
}

export default userController;