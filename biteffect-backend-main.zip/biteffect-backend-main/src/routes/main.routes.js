import express from "express";
import { assignHTTPError, errorResponder, invalidPathHandler } from "../middlewares/error.middlewares.js";
import userRouter from "./user.routes.js";
import { createRequire } from 'module';

const require = createRequire(import.meta.url);

const router = express.Router();

router.use('/user', userRouter)


router.use(assignHTTPError);
router.use(errorResponder);
router.use(invalidPathHandler);

export default router;    