import express from "express";
import { errorHandler } from "../handlers/error.handlers.js";
import userController from "../controllers/user.controller.js";
import {authGuard, optionalAuth} from "../middlewares/auth.middleware.js"
const userRouter = express.Router();

userRouter.post("/register", errorHandler(userController.userRegister));
userRouter.post("/login", errorHandler(userController.userLogin));
userRouter.post("/register/provider", errorHandler(userController.registerWithProvider));
userRouter.post("/login/provider", errorHandler(userController.loginWithProvider));

userRouter.get("/profile",authGuard("USER"), errorHandler(userController.getMyProfile));
userRouter.put("/profile",authGuard("USER"), errorHandler(userController.updateProfile));

userRouter.post("/password/reset", errorHandler(userController.requestPasswordReset));
userRouter.post("/password/verify-otp", errorHandler(userController.verifyResetOtp));
userRouter.post("/password/resend-otp", errorHandler(userController.resendResetOtp));
userRouter.post("/password/set-new", errorHandler(userController.setNewPassword));

userRouter.post("/add-user-detail",authGuard("USER"), errorHandler(userController.createUserData));

userRouter.post("/ai",authGuard("USER"), errorHandler(userController.getAIAnalysis));
userRouter.post("/ai/custom",authGuard("USER"), errorHandler(userController.analyzeCustomProduct));


userRouter.post("/product", optionalAuth("USER"), errorHandler(userController.getProduct));
userRouter.post("/product/alternatives", errorHandler(userController.getProductAlternatives));
userRouter.get("/product/search",authGuard("USER"), errorHandler(userController.searchProducts));

userRouter.get("/history",authGuard("USER"), errorHandler(userController.getMyHistory));
userRouter.delete("/history/all",authGuard("USER"), errorHandler(userController.deleteAllMyHistory));
userRouter.delete("/history/:id",authGuard("USER"), errorHandler(userController.deleteMyHistory));

userRouter.get("/cart",authGuard("USER"), errorHandler(userController.getMyCart));
userRouter.post("/cart",authGuard("USER"), errorHandler(userController.addToCart));
userRouter.delete("/cart/item/:id",authGuard("USER"), errorHandler(userController.deleteFromCart));
userRouter.delete("/cart",authGuard("USER"), errorHandler(userController.deleteCompleteCart));

userRouter.delete("/account",authGuard("USER"), errorHandler(userController.deleteMyAccount));

export default userRouter;
