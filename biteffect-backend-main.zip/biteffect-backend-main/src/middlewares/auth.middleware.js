import createError from "http-errors";
import jwt from "jsonwebtoken"

export function optionalAuth(role) {
    return (req, res, next) => {
        try {
            const token = req.header("Authorization");
            if (!token) {
                req.user = null;
                return next();
            }

            const jwtToken = token.split(' ')[1];
            const payload = jwt.verify(jwtToken, process.env.JWT_AUTHENTICATION_SECRET);

            if (payload.role !== role) {
                req.user = null;
                return next();
            }

            req.user = payload.user;
            next();
        } catch (err) {
            req.user = null;
            next();
        }
    }
}

export function authGuard(role){
    return (req, res, next)=>{
        try{
            const token = req.header("Authorization");
            if(!token)
                throw new Error("Authorization Token doesn't Exist")

            const jwtToken = token.split(' ')[1];

            const payload = jwt.verify(jwtToken, process.env.JWT_AUTHENTICATION_SECRET);
        console.log(payload,"payload")
            if(payload.role !== role)
                throw new Error("You don't have access to " + role + " role")

            req.user = payload.user;

            next();
        }
        catch(err){
            if (err.name === 'TokenExpiredError') {
                let error = new createError.Unauthorized("Token has expired. Please login again.")
                return next(error)
            }
            let error = new createError.Unauthorized(err.message)
            next(error)
        }
    }
}