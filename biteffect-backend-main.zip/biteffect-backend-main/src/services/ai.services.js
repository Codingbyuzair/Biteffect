import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { OpenAI } from 'openai';
import { PrismaClient } from '@prisma/client';
import createError from 'http-errors';

dotenv.config();

const openai = new OpenAI({ apiKey: process.env.OPEN_AI_KEY });
const prisma = new PrismaClient();

async function getProduct(barcode) {
  console.log("🚀 ~ getProduct ~ barcode:", barcode);
  try {
    const res = await fetch(`https://world.openfoodfacts.org/api/v0/product/${barcode}.json`);
    const data = await res.json();
    console.log("🚀 ~ getProduct ~ data:", data);

    if (data.status === 0 || !data.product) {
      throw new Error(`Product with barcode ${barcode} not found`);
    }
    
    return data;
  } catch (error) {
    console.error("Error fetching product:", error);
    throw error;
  }
}

const aiServices = {
  async analyzeFood(barcode, userId) {
    try {
      const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);

      let userData = {
        name: 'Unknown User',
        age: 'Unknown',
        gender: 'Unknown',
        weight: 'Unknown'
      };

      if (resolvedUserId) {
        try {
          const user = await prisma.user.findUnique({
            where: { id: resolvedUserId },
            select: {
              name: true,
              age: true,
              gender: true,
              weight: true
            }
          });
          
          if (user) {
            userData = {
              name: user.name || 'Unknown User',
              age: user.age || 'Unknown',
              gender: user.gender || 'Unknown',
              weight: user.weight || 'Unknown'
            };
          }
        } catch (userError) {
          console.log('Could not fetch user data, using defaults:', userError.message);
        }
      }

      const productData = await getProduct(barcode);
      console.log("🚀 ~ analyzeFood ~ productData:", productData)

      if (!productData || !productData.product) {
        throw createError(404, `Product with barcode ${barcode} not found in database`);
      }

      const product = productData.product;

      const foodInfo = {
        productName: product.product_name || 'Unknown Product',
        brand: product.brands || 'Unknown Brand',
        ingredients: product.ingredients_text || 'No ingredients listed',
        nutriments: {
          calories: product.nutriments?.['energy-kcal_100g'] || product.nutriments?.energy_100g || 0,
          caloriesPerServing: product.nutriments?.['energy-kcal_serving'] || 0,
          fat: product.nutriments?.fat_100g || 0,
          saturatedFat: product.nutriments?.['saturated-fat_100g'] || 0,
          carbohydrates: product.nutriments?.carbohydrates_100g || 0,
          sugars: product.nutriments?.sugars_100g || 0,
          fiber: product.nutriments?.fiber_100g || 0,
          proteins: product.nutriments?.proteins_100g || 0,
          salt: product.nutriments?.salt_100g || 0,
          sodium: product.nutriments?.sodium_100g || 0
        },
        additives: product.additives_tags || [],
        allergens: product.allergens_tags || [],
        nutritionGrade: product.nutrition_grades || product.nutriscore_grade || 'unknown',
        categories: product.categories || 'unknown',
        novaGroup: product.nova_group || 'unknown',
        servingSize: product.serving_size || product.quantity || 'unknown',
        quantity: product.quantity || 'unknown'
      };

      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an expert nutritionist and health analyst. Analyze food products based on their nutritional content and ingredients, considering the user\'s health profile. You must ONLY return valid JSON without any markdown formatting or extra text.'
          },
          {
            role: 'user',
            content: `Analyze this food product for a person with the following profile:

USER PROFILE:
- Name: ${userData.name}
- Age: ${userData.age}
- Gender: ${userData.gender}
- Weight: ${userData.weight}

FOOD PRODUCT DATA:
${JSON.stringify(foodInfo, null, 2)}

Analyze the impact of this food on the user's health and provide recommendations. Return ONLY a JSON object with this exact structure:

{
  "productAnalysis": {
    "name": "${foodInfo.productName}",
    "brand": "${foodInfo.brand}",
    "overallHealthScore": 1-10,
    "nutritionGrade": "${foodInfo.nutritionGrade}",
    "novaGroup": "${foodInfo.novaGroup}",
    "servingSize": "${foodInfo.servingSize}"
  },
  "weightImpact": {
    "impact": "low/medium/high/very-high",
    "rating": 1-10,
    "details": ["2-3 short bullet points (max 1 line each) about weight impact"],
    "recommendation": "1 short recommendation"
  },
  "skinImpact": {
    "impact": "low/medium/high/very-high", 
    "rating": 1-10,
    "details": ["2-3 short bullet points (max 1 line each) about skin impact"],
    "recommendation": "1 short recommendation"
  },
  "overallHealthImpact": {
    "impact": "positive/neutral/negative/very-negative",
    "rating": 1-10,
    "details": ["2-3 short bullet points (max 1 line each) about overall health"],
    "recommendation": "1 short recommendation",
    "alternatives": "1 short alternative suggestion"
  }
}

IMPORTANT: 
- All 'details' fields must be JSON arrays of 2-3 very short bullet strings (max 10-12 words each)
- Keep all recommendations under 15 words
- Be direct and concise - no fluff or extra explanations`
          }
        ],
        max_tokens: 1000,
        temperature: 0.3
      });

      const analysis = response.choices[0]?.message?.content;
      
      if (!analysis) {
        throw new Error('No response from AI service');
      }

      const cleanedResponse = analysis.replace(/```json\n?|\n?```/g, '').trim();
      
      try {
        const parsedAnalysis = JSON.parse(cleanedResponse);

        const addedImage = {
          ...parsedAnalysis,
          imageURL: product.image_url || product.image_front_url || ''
        }
        return addedImage;
      } catch (parseError) {
        console.error('JSON Parse Error:', parseError);
        console.error('Raw AI Response:', analysis);
        throw new Error('Invalid AI response format');
      }

    } catch (error) {
      console.error('Error analyzing food:', error);

      if (typeof error?.message === 'string' && error.message.includes('not found')) {
        throw createError(404, `Product with barcode ${barcode} not found in database`);
      }

      return {
        error: true,
        message: "Unable to analyze product - please try again",
        details: error.message,
        productAnalysis: {
          name: "Unknown Product",
          brand: "Unknown",
          overallHealthScore: 0,
          nutritionGrade: "unknown",
          novaGroup: "unknown",
          servingSize: "unknown"
        },
        weightImpact: {
          impact: "medium",
          rating: 0,
          details: [],
          recommendation: "Consult with a nutritionist"
        },
        skinImpact: {
          impact: "medium",
          rating: 0,
          details: [],
          recommendation: "Maintain a balanced diet"
        },
        overallHealthImpact: {
          impact: "neutral",
          rating: 0,
          details: [],
          recommendation: "Consult with your doctor for dietary advice",
          alternatives: "Choose whole, unprocessed foods when possible"
        }
      };
    }
  },



  async analyzeProductManual({ productName, companyName, imageURL }, userId) {
    try {
      const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);

      let userData = {
        name: 'Unknown User',
        age: 'Unknown',
        gender: 'Unknown',
        weight: 'Unknown'
      };

      if (resolvedUserId) {
        try {
          const user = await prisma.user.findUnique({
            where: { id: resolvedUserId },
            select: {
              name: true,
              age: true,
              gender: true,
              weight: true
            }
          });
          if (user) {
            userData = {
              name: user.name || 'Unknown User',
              age: user.age || 'Unknown',
              gender: user.gender || 'Unknown',
              weight: user.weight || 'Unknown'
            };
          }
        } catch {}
      }

      const manualInfo = {
        productName: productName || 'Unknown Product',
        brand: companyName || 'Unknown Brand',
        imageURL: imageURL || ''
      };

      const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an expert nutritionist and health analyst. Analyze food products based on their nutritional content and ingredients, considering the user\'s health profile. You must ONLY return valid JSON without any markdown formatting or extra text.'
          },
          {
            role: 'user',
            content: `Analyze this user-submitted food item.

USER PROFILE:
- Name: ${userData.name}
- Age: ${userData.age}
- Gender: ${userData.gender}
- Weight: ${userData.weight}

USER SUBMISSION:
- Product Name: ${manualInfo.productName}
- Brand/Company: ${manualInfo.brand}
- Image URL: ${manualInfo.imageURL}

Return ONLY a JSON object with this exact structure:
{
  "productAnalysis": {
    "name": "${manualInfo.productName}",
    "brand": "${manualInfo.brand}",
    "overallHealthScore": 1-10,
    "nutritionGrade": "unknown",
    "novaGroup": "unknown",
    "servingSize": "unknown"
  },
  "weightImpact": {
    "impact": "low/medium/high/very-high",
    "rating": 1-10,
    "details": ["2-3 short bullet points (max 1 line each) about weight impact"],
    "recommendation": "1 short recommendation"
  },
  "skinImpact": {
    "impact": "low/medium/high/very-high", 
    "rating": 1-10,
    "details": ["2-3 short bullet points (max 1 line each) about skin impact"],
    "recommendation": "1 short recommendation"
  },
  "overallHealthImpact": {
    "impact": "positive/neutral/negative/very-negative",
    "rating": 1-10,
    "details": ["2-3 short bullet points (max 1 line each) about overall health"],
    "recommendation": "1 short recommendation",
    "alternatives": "1 short alternative suggestion"
  }
}

IMPORTANT: 
- All 'details' fields must be JSON arrays of 2-3 very short bullet strings (max 10-12 words each)
- Keep all recommendations under 15 words
- Be direct and concise - no fluff or extra explanations`
          }
        ],
        max_tokens: 800,
        temperature: 0.3
      });

      const analysis = response.choices[0]?.message?.content;
      if (!analysis) throw new Error('No response from AI service');

      const cleanedResponse = analysis.replace(/```json\n?|\n?```/g, '').trim();
      const parsedAnalysis = JSON.parse(cleanedResponse);

      if (resolvedUserId) {
        try {
          await prisma.history.create({
            data: {
              title: manualInfo.productName,
              imageURL: manualInfo.imageURL || '',
              weightImpact: parsedAnalysis?.weightImpact?.impact || 'unknown',
              weightImpactDetail: Array.isArray(parsedAnalysis?.weightImpact?.details) ? parsedAnalysis.weightImpact.details : [],
              skinImpact: parsedAnalysis?.skinImpact?.impact || 'unknown',
              skinImpactDetail: Array.isArray(parsedAnalysis?.skinImpact?.details) ? parsedAnalysis.skinImpact.details : [],
              overallImpact: parsedAnalysis?.overallHealthImpact?.impact || 'unknown',
              overallImpactDetail: Array.isArray(parsedAnalysis?.overallHealthImpact?.details) ? parsedAnalysis.overallHealthImpact.details : [],
              userId: resolvedUserId
            }
          });

          // Update streak logic
          const user = await prisma.user.findUnique({
            where: { id: resolvedUserId },
            select: {
              streak: true,
              lastStreakDate: true
            }
          });

          if (user) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            const lastStreakDate = user.lastStreakDate ? new Date(user.lastStreakDate) : null;
            if (lastStreakDate) {
              lastStreakDate.setHours(0, 0, 0, 0);
            }

            let newStreak = user.streak || 0;
            const daysDifference = lastStreakDate 
              ? Math.floor((today - lastStreakDate) / (1000 * 60 * 60 * 24))
              : null;

            if (!lastStreakDate) {
              // First time scanning - start streak at 1
              newStreak = 1;
            } else if (daysDifference === 1) {
              // Scanned yesterday - increment streak
              newStreak = (user.streak || 0) + 1;
            } else if (daysDifference === 0) {
              // Scanned today already - keep current streak
              newStreak = user.streak || 0;
            } else {
              // 2+ days gap or future date - reset streak to 1
              newStreak = 1;
            }

            // Update user streak and lastStreakDate
            await prisma.user.update({
              where: { id: resolvedUserId },
              data: {
                streak: newStreak,
                lastStreakDate: today
              }
            });
          }
        } catch (historyError) {
          console.error('Failed to save manual history or update streak:', historyError);
        }
      }

      return parsedAnalysis;
    } catch (error) {
      console.error('Error analyzing manual product:', error);
      throw error;
    }
  },
};

export default aiServices;