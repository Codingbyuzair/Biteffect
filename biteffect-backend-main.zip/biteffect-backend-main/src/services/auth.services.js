import { PrismaClient } from "@prisma/client";
import createError from "http-errors";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import { createTransporter } from "../utils/mailer.js";
import { verifyFirebaseToken } from "../config/firebase.config.js";
import crypto from "crypto";
const prisma = new PrismaClient();

const authServices = {
  async getUserPayload(user) {
    delete user.password
    let payload = {
      user: user.id,
      role: user.role,
      email: user.email
    }

    let resBody = {
      user
    }

    let authToken = jwt.sign(payload, process.env.JWT_AUTHENTICATION_SECRET, { expiresIn: '7d' });
    resBody.authToken = authToken;

    return resBody;
  },
  async userRegister( name, email, password, userData = {}) {
    const validateEmail = (email) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    };

  

    if (!name || name.trim().length < 2) {
      throw createError(400, "Name must be at least 2 characters long");
    }

    if (!email || !validateEmail(email)) {
      throw createError(400, "Please provide a valid email address");
    }

    if (!password || password.length < 8) {
      throw createError(400, "Password must be at least 8 characters long");
    }


    const existingUser = await prisma.user.findFirst({
      where: {
        email: email.toLowerCase()
      }
    });

    if (existingUser) {
      throw createError(400, "User with this email already exists");
    }

    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    const newUser = await prisma.user.create({
      data: {
        email: email.toLowerCase(),
        name: name.trim(),
        password: hashedPassword,
        provider: 'EMAIL',
        userImage: userData.userImage || null,
        gender: userData.gender || null,
        age: userData.age || null,
        weight: userData.weight || null
      }
    });

    const { password: _, ...userWithoutPassword } = newUser;
    const payload = await authServices.getUserPayload(userWithoutPassword);
    console.log("🚀 ~ userRegister ~ payload:", payload);
    return {
      user: payload
    };
  },
  async userLogin(email, password) {
    if (!email || !password) {
      throw createError(400, "Email and password are required");
    }

    const user = await prisma.user.findFirst({
      where: {
        email: email.toLowerCase()
      }
    });

    if (!user) {
      throw createError(404, "User not found with this email");
    }

    // Only allow password login for EMAIL provider
    if (user.provider !== 'EMAIL') {
      throw createError(400, `This email is registered with ${user.provider} provider. Please use ${user.provider} authentication.`);
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      throw createError(401, "Invalid password");
    }

    const payload = await authServices.getUserPayload(user);

    return {
      ...payload
    };
  },

  async registerWithProvider(firebaseToken, type, userData = {}) {
    if (!firebaseToken) {
      throw createError(400, "Firebase token is required");
    }

    if (!type || !['google', 'apple'].includes(type.toLowerCase())) {
      throw createError(400, "Provider type must be 'google' or 'apple'");
    }

    try {
      const decodedToken = await verifyFirebaseToken(firebaseToken);
      console.log("🚀 ~ decodedToken:", decodedToken)
      const email = decodedToken.email;
      const name = decodedToken.name || decodedToken.display_name || userData.name || 'User';
      const userImage = decodedToken.picture || decodedToken.photoURL || userData.userImage || null;

      if (!email) {
        throw createError(400, "Email not found in Firebase token");
      }

      // Check if user already exists
      const existingUser = await prisma.user.findFirst({
        where: {
          email: email.toLowerCase()
        }
      });

      if (existingUser) {
        throw createError(400, "User with this email already exists");
      }

      const randomPassword = crypto.randomBytes(32).toString('hex');
      const saltRounds = 10;
      const hashedPassword = await bcrypt.hash(randomPassword, saltRounds);

      const provider = type.toUpperCase() === 'GOOGLE' ? 'GOOGLE' : 'APPLE';

      // Create new user
      const newUser = await prisma.user.create({
        data: {
          email: email.toLowerCase(),
          name: name.trim(),
          password: hashedPassword, // Store random password
          provider: provider,
          userImage: userImage,
          gender: userData.gender || null,
          age: userData.age || null,
          weight: userData.weight || null
        }
      });

      const { password: _, ...userWithoutPassword } = newUser;
      const payload = await authServices.getUserPayload(userWithoutPassword);

      return {
        user: payload
      };
    } catch (error) {
      console.error('Error in registerWithProvider:', error);
      if (error.status || error.statusCode) {
        throw error;
      }
      throw createError(401, "Invalid Firebase token or authentication failed");
    }
  },

  async loginWithProvider(firebaseToken, type) {
    if (!firebaseToken) {
      throw createError(400, "Firebase token is required");
    }

    if (!type || !['google', 'apple'].includes(type.toLowerCase())) {
      throw createError(400, "Provider type must be 'google' or 'apple'");
    }

    try {
      // Verify Firebase token
      const decodedToken = await verifyFirebaseToken(firebaseToken);
      const email = decodedToken.email;

      if (!email) {
        throw createError(400, "Email not found in Firebase token");
      }

      // Find user by email
      const user = await prisma.user.findFirst({
        where: {
          email: email.toLowerCase()
        }
      });

      if (!user) {
        throw createError(404, "User not found with this email. Please register first.");
      }

      // Verify provider matches
      const provider = type.toUpperCase() === 'GOOGLE' ? 'GOOGLE' : 'APPLE';
      if (user.provider !== provider) {
        throw createError(400, `This email is registered with ${user.provider} provider, not ${provider}`);
      }

      const payload = await authServices.getUserPayload(user);

      return {
        ...payload
      };
    } catch (error) {
      console.error('Error in loginWithProvider:', error);
      if (error.status || error.statusCode) {
        throw error;
      }
      throw createError(401, "Invalid Firebase token or authentication failed");
    }
  },

  async getMyProfile(userId) {
    if (!userId) {
      throw createError(400, "User ID is required");
    }

    const user = await prisma.user.findUnique({
      where: {
        id: userId
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        userImage: true,
        gender: true,
        age: true,
        weight: true,
        streak: true,
        lastStreakDate: true,
        provider: true,
        createdAt: true,
        updatedAt: true
      }
    });

    if (!user) {
      throw createError(404, "User not found with this id");
    }

    // Get history statistics
    const historyItems = await prisma.history.findMany({
      where: { userId },
      select: { finalScore: true }
    });

    const scan = historyItems.length;
    let avgScore = 0;
    
    if (scan > 0) {
      const totalScore = historyItems.reduce((sum, item) => {
        return sum + (item.finalScore || 0);
      }, 0);
      avgScore = Number((totalScore / scan).toFixed(2));
    }

    return {
      user: {
        ...user,
        scan,
        avgScore
      }
    };
  },

  async updateProfile(userId, userData) {
    if (!userId) {
      throw createError(400, "User ID is required");
    }

    const existingUser = await prisma.user.findUnique({
      where: { id: userId }
    });

    if (!existingUser) {
      throw createError(404, "User not found");
    }

    const updateData = {};
    let hasUpdates = false;

    if (userData.name !== undefined) {
      updateData.name = userData.name.trim();
      hasUpdates = true;
    }
    if (userData.email !== undefined) {
      const validateEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
      };
      if (!validateEmail(userData.email)) {
        throw createError(400, "Please provide a valid email address");
      }
      updateData.email = userData.email.toLowerCase();
      hasUpdates = true;
    }
    if (userData.userImage !== undefined) {
      updateData.userImage = userData.userImage;
      hasUpdates = true;
    }
    if (userData.gender !== undefined) {
      updateData.gender = userData.gender;
      hasUpdates = true;
    }
    if (userData.age !== undefined) {
      updateData.age = userData.age;
      hasUpdates = true;
    }
    if (userData.weight !== undefined) {
      updateData.weight = userData.weight;
      hasUpdates = true;
    }

    let updatedUser = existingUser;
    if (hasUpdates) {
      updatedUser = await prisma.user.update({
        where: { id: userId },
        data: updateData,
        select: {
          id: true,
          email: true,
          name: true,
          role: true,
          userImage: true,
          gender: true,
          age: true,
          weight: true,
          createdAt: true,
          updatedAt: true
        }
      });
    }

    return {
      user: updatedUser
    };
  },

  async requestPasswordReset(email) {
    const user = await prisma.user.findFirst({ where: { email } });
    if (!user) {
      throw createError(404, 'User not found');
    }

    // Only allow password reset for EMAIL provider
    if (user.provider !== 'EMAIL') {
      throw createError(400, `Password reset is not available for ${user.provider} provider. Please use ${user.provider} authentication.`);
    }

    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    await prisma.verifiedCredential.create({
      data: {
        otp,
        email: user.email,
        userId: user.id
      }
    });

    const transporter = createTransporter();
    await transporter.sendMail({
      from: `"Support" <${process.env.SMTP_USERNAME}>`,
      to: user.email,
      subject: 'Password Reset OTP',
      text: `Your password reset code is: ${otp}`
    });

    return { success: true, userId: user.id };
  },

  async verifyResetOtp(email, otp) {
    console.log("🚀 ~ verifyResetOtp ~ otp:", otp)
    console.log("🚀 ~ verifyResetOtp ~ email:", email)
    
    // First find the user to get the userId
    const user = await prisma.user.findFirst({ where: { email } });
    if (!user) {
      throw createError(404, 'User not found');
    }

    const credential = await prisma.verifiedCredential.findFirst({
      where: {
        userId: user.id,
        otp,
        verified: false
      },
      orderBy: { createdAt: 'desc' }
    });
    console.log("🚀 ~ verifyResetOtp ~ credential:", credential)

    if (!credential) {
      throw createError(400, 'Invalid or expired OTP');
    }

    await prisma.verifiedCredential.update({
      where: { id: credential.id },
      data: { verified: true }
    });

    return { success: true };
  },

  async resendResetOtp(email) {
    const user = await prisma.user.findFirst({ where: { email } });
    if (!user) {
      throw createError(404, 'User not found');
    }

    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    await prisma.verifiedCredential.create({
      data: {
        otp,
        email: user.email,
        userId: user.id
      }
    });

    // Send OTP via email
    const transporter = createTransporter();
    await transporter.sendMail({
      from: `"Support" <${process.env.SMTP_USERNAME}>`,
      to: user.email,
      subject: 'Password Reset OTP',
      text: `Your password reset code is: ${otp}`
    });

    return { success: true };
  },

  async setNewPassword(email, newPassword) {
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.user.update({
      where: { email },
      data: { password: hashedPassword }
    });

    return { success: true };
  },

  async deleteMyAccount(userId) {
    if (!userId) {
      throw createError(400, 'User ID is required');
    }

    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      throw createError(404, 'User not found');
    }

    // Delete all related data in the correct order
    // 1. Delete cart items (if cart exists)
    const userCart = await prisma.cart.findUnique({
      where: { userId },
      include: { cartItems: true }
    });

    if (userCart) {
      // Delete all cart items
      await prisma.cartItem.deleteMany({
        where: { cartId: userCart.id }
      });

      // Delete the cart
      await prisma.cart.delete({
        where: { id: userCart.id }
      });
    }

    // 2. Delete all history
    const historyCount = await prisma.history.count({
      where: { userId }
    });
    await prisma.history.deleteMany({
      where: { userId }
    });

    // 3. Delete all verified credentials (OTP records)
    const credentialsCount = await prisma.verifiedCredential.count({
      where: { userId }
    });
    await prisma.verifiedCredential.deleteMany({
      where: { userId }
    });

    // 4. Finally, delete the user
    await prisma.user.delete({
      where: { id: userId }
    });

    return {
      success: true,
      message: 'Account and all related data deleted successfully',
      deletedData: {
        cartItems: userCart?.cartItems?.length || 0,
        historyItems: historyCount,
        credentials: credentialsCount
      }
    };
  }

}
export default authServices;