
import createError from 'http-errors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { PrismaClient } from '@prisma/client';
import { collectProductImages } from '../utils/imageProcessor.js';
import { productCache, searchCache, alternativesCache } from '../utils/cache.js';

const prisma = new PrismaClient();

const REQUIRED_PRODUCT_FIELDS = [
  'product_name', 'brands', 'code', 'quantity',
  'image_url', 'image_front_url', 'image_ingredients_url',
  'image_nutrition_url', 'image_packaging_url',
  'nutriments', 'additives_tags', 'labels_tags',
  'ingredients_analysis_tags', 'pnns_groups_1',
  'pnns_groups_1_tags', 'pnns_groups_2', 'pnns_groups_2_tags',
].join(',');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const additivesPath = path.join(__dirname, '..', 'utils', 'additives.json');
const nutrientsPath = path.join(__dirname, '..', 'utils', 'nutrients.json');
const categoriesPath = path.join(__dirname, '..', 'utils', 'categories.json');
let additivesById = null;
let additivesByName = null;
let nutrientsData = null;
let categoryLookup = null;

function loadAdditivesData() {
  if (!additivesById) {
    try {
      const additivesFile = fs.readFileSync(additivesPath, 'utf8');
      const additivesArray = JSON.parse(additivesFile);
      additivesById = new Map();
      additivesByName = new Map();
      for (const additive of additivesArray) {
        additivesById.set(additive.id, additive);
        if (additive.name) {
          additivesByName.set(additive.name, additive);
        }
      }
    } catch (error) {
      additivesById = new Map();
      additivesByName = new Map();
    }
  }
  return { byId: additivesById, byName: additivesByName };
}

function loadNutrientsData() {
  if (!nutrientsData) {
    try {
      const nutrientsFile = fs.readFileSync(nutrientsPath, 'utf8');
      nutrientsData = JSON.parse(nutrientsFile);
    } catch (error) {
      nutrientsData = { negative: {}, positive: {} };
    }
  }
  return nutrientsData;
}

function loadCategoryLookup() {
  if (!categoryLookup) {
    try {
      const categoriesFile = fs.readFileSync(categoriesPath, 'utf8');
      const categoriesArray = JSON.parse(categoriesFile);
      categoryLookup = new Map();
      for (const cat of categoriesArray) {
        if (cat.tags && Array.isArray(cat.tags)) {
          for (const tag of cat.tags) {
            categoryLookup.set(tag, { id: cat.id, fiber: cat.fiber, protein: cat.protein, pnnsTag: cat.tags[0] });
          }
        }
      }
    } catch (error) {
      categoryLookup = new Map();
    }
  }
  return categoryLookup;
}

function getCategoryConfig(product) {
  const lookup = loadCategoryLookup();
  const tags = product.pnns_groups_1_tags;
  if (Array.isArray(tags) && tags.length > 0) {
    const config = lookup.get(tags[0]);
    if (config) return config;
  }
  const group = product.pnns_groups_1;
  if (group && group !== 'unknown') {
    const config = lookup.get(group.toLowerCase().replace(/\s+/g, '-'));
    if (config) return config;
  }
  return { id: 'unknown', fiber: true, protein: true, pnnsTag: null };
}

loadAdditivesData();
loadNutrientsData();
loadCategoryLookup();

function getNutrientPoints(nutrientName, value, nutrientType = 'negative') {
  const nutrients = loadNutrientsData();
  const nutrientConfig = nutrients[nutrientType]?.[nutrientName];

  if (!nutrientConfig) {
    return 0;
  }

  const thresholds = nutrientConfig.thresholds;
  const val = Number(value) || 0;

  if (nutrientType === 'negative') {
    if (val <= thresholds.green.max) {
      return thresholds.green.points;
    } else if (val >= thresholds.amber.min && val < thresholds.amber.max) {
      return thresholds.amber.points;
    } else {
      return thresholds.red.points;
    }
  } else {
    if (val >= thresholds.green.min) {
      return thresholds.green.points;
    } else if (val >= thresholds.amber.min && val < thresholds.amber.max) {
      return thresholds.amber.points;
    } else {
      return thresholds.red.points;
    }
  }
}

function calculateNutritionScore(nutriments, categoryConfig = { fiber: true, protein: true }) {
  const includeFiber = categoryConfig.fiber;
  const includeProtein = categoryConfig.protein;

  const points = {
    sugar: getNutrientPoints('sugar', nutriments?.sugars_100g, 'negative'),
    saturatedFat: getNutrientPoints('saturatedFat', nutriments?.['saturated-fat_100g'], 'negative'),
    salt: getNutrientPoints('salt', nutriments?.salt_100g, 'negative'),
    fiber: includeFiber ? getNutrientPoints('fibre', nutriments?.fiber_100g, 'positive') : null,
    protein: includeProtein ? getNutrientPoints('protein', nutriments?.proteins_100g, 'positive') : null,
  };

  const sumPoints = Object.values(points).filter(p => p !== null).reduce((sum, p) => sum + p, 0);
  const maxPoints = 9 + (includeFiber ? 3 : 0) + (includeProtein ? 3 : 0);
  const nutritionSubscore = (sumPoints / maxPoints) * 100;
  const weightedNutritionScore = nutritionSubscore * 0.6;

  return {
    points,
    sumPoints,
    maxPoints,
    nutritionSubscore: Number(nutritionSubscore.toFixed(2)),
    weightedScore: Number(weightedNutritionScore.toFixed(2)),
    outOf: 60
  };
}

function calculateAdditiveScore(filteredAdditives) {
  const baseAdditiveScore = 30;
  let totalPenalty = 0;
  let penaltyBreakdown = {
    green: 0,
    amber: 0,
    red: 0
  };

  if (!filteredAdditives || filteredAdditives.length === 0) {
    return {
      penaltyBreakdown: { green: 0, amber: 0, red: 0 },
      totalPenalty: 0,
      overflowPenalty: 0,
      additiveSubscore: 100,
      weightedScore: baseAdditiveScore,
      outOf: 30
    };
  }

  filteredAdditives.forEach(additive => {
    const color = additive.color?.toLowerCase() || '';
    if (color === 'green') {
      penaltyBreakdown.green++;
    } else if (color === 'amber') {
      penaltyBreakdown.amber++;
      totalPenalty += 6;
    } else if (color === 'red') {
      penaltyBreakdown.red++;
      totalPenalty += 30;
    }
  });

  const cappedPenalty = Math.min(totalPenalty, baseAdditiveScore);
  const finalAdditiveScore = baseAdditiveScore - cappedPenalty;
  const overflowPenalty = 0;
  const additiveSubscore = (finalAdditiveScore / baseAdditiveScore) * 100;

  return {
    penaltyBreakdown,
    totalPenalty,
    overflowPenalty,
    baseScore: baseAdditiveScore,
    finalScore: Number(finalAdditiveScore.toFixed(2)),
    additiveSubscore: Number(additiveSubscore.toFixed(2)),
    weightedScore: Number(finalAdditiveScore.toFixed(2)),
    outOf: 30
  };
}

function calculateOrganicScore(isOrganic) {
  const organicScore = isOrganic ? 100 : 0;
  const weightedOrganicScore = organicScore * 0.1;

  return {
    organicScore,
    weightedScore: Number(weightedOrganicScore.toFixed(2)),
    outOf: 10
  };
}

async function getProduct(barcode) {
  const cacheKey = `product:${barcode}`;
  const cached = productCache.get(cacheKey);
  if (cached) return cached;

  try {
    const startTime = Date.now();
    const res = await fetch(
      `https://world.openfoodfacts.org/api/v0/product/${barcode}.json?fields=${REQUIRED_PRODUCT_FIELDS},compared_to_category`,
      { signal: AbortSignal.timeout(50000) }
    );

    if (!res.ok) {
      throw createError(404, `Product with barcode ${barcode} not found`);
    }

    const data = await res.json();
    console.log(`[Product] OpenFoodFacts responded in ${Date.now() - startTime}ms (barcode: ${barcode})`);

    if (data.status === 0 || !data.product) {
      throw createError(404, `Product with barcode ${barcode} not found`);
    }

    productCache.set(cacheKey, data);
    return data;
  } catch (error) {
    if (error.status || error.statusCode) {
      throw error;
    }
    throw createError(404, `Product with barcode ${barcode} not found`);
  }
}
async function fetchProductSearch(searchTerm, page = 1, pageSize = 5) {
  const cacheKey = `search:${searchTerm.toLowerCase()}:${page}:${pageSize}`;
  const cached = searchCache.get(cacheKey);
  if (cached) return cached;

  try {
    const url = `https://search.openfoodfacts.org/search?q=${encodeURIComponent(searchTerm)}&page_size=${pageSize}&page=${page}&fields=${REQUIRED_PRODUCT_FIELDS}`;

    const startTime = Date.now();
    const res = await fetch(url, { signal: AbortSignal.timeout(50000) });

    if (!res.ok) {
      throw createError(500, 'Error searching products');
    }

    const data = await res.json();
    console.log(`[Search] OpenFoodFacts responded in ${Date.now() - startTime}ms (term: "${searchTerm}", results: ${data.count || 0})`);

    const normalized = {
      products: data.hits || [],
      count: data.count || 0,
    };

    searchCache.set(cacheKey, normalized);
    return normalized;
  } catch (error) {
    if (error.status || error.statusCode) {
      throw error;
    }
    throw createError(500, 'Error searching products');
  }
}

async function fetchAlternativesByPnns(pnnsGroup, currentBarcode, pageSize = 5) {
  const cacheKey = `alt:pnns:${pnnsGroup}:${pageSize}`;
  let data = alternativesCache.get(cacheKey);

  if (!data) {
    try {
      const url = `https://world.openfoodfacts.org/api/v2/search?pnns_groups_1_tags=${encodeURIComponent(pnnsGroup)}&page_size=${pageSize}&page=1&fields=${REQUIRED_PRODUCT_FIELDS}`;

      const startTime = Date.now();
      const res = await fetch(url, { signal: AbortSignal.timeout(50000) });

      if (!res.ok) {
        console.log(`[Alternatives] OpenFoodFacts returned ${res.status} for pnns "${pnnsGroup}"`);
        return { products: [] };
      }

      const rawData = await res.json();
      console.log(`[Alternatives] OpenFoodFacts responded in ${Date.now() - startTime}ms (pnns: "${pnnsGroup}", results: ${rawData.count || 0}, products: ${rawData.products?.length || 0})`);

      data = {
        products: rawData.products || [],
        count: rawData.count || 0,
      };
      alternativesCache.set(cacheKey, data);
    } catch (error) {
      console.log(`[Alternatives] Fetch error for pnns "${pnnsGroup}": ${error.message}`);
      return { products: [] };
    }
  }

  if (data.products && Array.isArray(data.products)) {
    return {
      ...data,
      products: data.products.filter(product => {
        const barcode = product.code || product._id;
        return barcode !== currentBarcode;
      }),
    };
  }

  return data;
}

async function fetchAlternativesByPnns2(pnnsGroup2, currentBarcode, pageSize = 5) {
  const cacheKey = `alt:pnns2:${pnnsGroup2}:${pageSize}`;
  let data = alternativesCache.get(cacheKey);

  if (!data) {
    try {
      const url = `https://world.openfoodfacts.org/api/v2/search?pnns_groups_2_tags=${encodeURIComponent(pnnsGroup2)}&page_size=${pageSize}&page=1&fields=${REQUIRED_PRODUCT_FIELDS}`;

      const startTime = Date.now();
      const res = await fetch(url, { signal: AbortSignal.timeout(50000) });

      if (!res.ok) {
        console.log(`[Alternatives] OpenFoodFacts returned ${res.status} for pnns2 "${pnnsGroup2}"`);
        return { products: [] };
      }

      const rawData = await res.json();
      console.log(`[Alternatives] OpenFoodFacts responded in ${Date.now() - startTime}ms (pnns2: "${pnnsGroup2}", results: ${rawData.count || 0}, products: ${rawData.products?.length || 0})`);

      data = {
        products: rawData.products || [],
        count: rawData.count || 0,
      };
      alternativesCache.set(cacheKey, data);
    } catch (error) {
      console.log(`[Alternatives] Fetch error for pnns2 "${pnnsGroup2}": ${error.message}`);
      return { products: [] };
    }
  }

  if (data.products && Array.isArray(data.products)) {
    return {
      ...data,
      products: data.products.filter(product => {
        const barcode = product.code || product._id;
        return barcode !== currentBarcode;
      }),
    };
  }

  return data;
}

function quickScore(rawProduct) {
  const categoryConfig = getCategoryConfig(rawProduct);
  const nutritionScore = calculateNutritionScore(rawProduct.nutriments, categoryConfig);

  const { byId } = loadAdditivesData();
  const tags = rawProduct.additives_tags || [];
  let totalPenalty = 0;
  let redCount = 0;
  for (const tag of tags) {
    const additive = byId.get(tag);
    if (additive) {
      const color = (additive.color || '').toLowerCase();
      if (color === 'amber') totalPenalty += 6;
      else if (color === 'red') { totalPenalty += 30; redCount++; }
    }
  }
  const additiveWeighted = Math.max(0, 30 - totalPenalty);

  const labels = rawProduct.labels_tags || [];
  const isOrganic = labels.includes('en:organic') || labels.includes('en:eu-organic');
  const organicWeighted = isOrganic ? 10 : 0;

  let score = Math.max(0, nutritionScore.weightedScore + additiveWeighted + organicWeighted);
  if (redCount >= 4) {
    score = Math.min(score, 30);
  } else if (redCount >= 2) {
    score = Math.min(score, 50);
  }
  return score;
}

function scoreAndFilter(products, currentScoreOutOf100) {
  if (!products || !Array.isArray(products)) return [];
  return products
    .map(rawProduct => {
      if (!rawProduct.code && !rawProduct._id) return null;
      const qs = quickScore(rawProduct);
      if (qs <= currentScoreOutOf100) return null;
      return { rawProduct, quickScoreValue: qs };
    })
    .filter(Boolean)
    .sort((a, b) => b.quickScoreValue - a.quickScoreValue)
    .slice(0, 3);
}

function formatProduct(product, barcode) {
  const { byId } = loadAdditivesData();
  const productAdditivesTags = product.additives_tags || [];
  const filteredAdditives = [];
  for (const tag of productAdditivesTags) {
    const additive = byId.get(tag);
    if (additive) {
      filteredAdditives.push(additive);
    }
  }

  const labelsTags = product.labels_tags || [];
  const isOrganic = labelsTags.includes('en:organic') || labelsTags.includes('en:eu-organic');
  const isHalal = labelsTags.some(tag => tag.includes('halal'));

  const analysisTags = product.ingredients_analysis_tags || [];
  const isVegan = analysisTags.includes('en:vegan')
    ? true
    : analysisTags.includes('en:non-vegan')
      ? false
      : null;

  const categoryConfig = getCategoryConfig(product);
  const nutritionScore = calculateNutritionScore(product.nutriments, categoryConfig);
  const additiveScore = calculateAdditiveScore(filteredAdditives);
  const organicScore = calculateOrganicScore(isOrganic);

  const rawFinalScore = nutritionScore.weightedScore + additiveScore.weightedScore + organicScore.weightedScore - additiveScore.overflowPenalty;
  let finalScoreOutOf100 = Math.max(0, rawFinalScore);
  let finalScoreOutOf10 = Number((finalScoreOutOf100 / 10).toFixed(2));

  const redCount = additiveScore.penaltyBreakdown.red;
  if (redCount >= 4) {
    finalScoreOutOf10 = Math.min(finalScoreOutOf10, 3);
    finalScoreOutOf100 = Number((finalScoreOutOf10 * 10).toFixed(2));
  } else if (redCount >= 2) {
    finalScoreOutOf10 = Math.min(finalScoreOutOf10, 5);
    finalScoreOutOf100 = Number((finalScoreOutOf10 * 10).toFixed(2));
  }

  const images = collectProductImages(product);
  const mainImageURL = product.image_url || product.image_front_url || '';
  const n = product.nutriments || {};

  const pnns2Tags = product.pnns_groups_2_tags;
  const pnns2Tag = Array.isArray(pnns2Tags) && pnns2Tags.length > 0 ? pnns2Tags[0] : null;
  const pnns1Tag = categoryConfig.pnnsTag;

  return {
    productName: product.product_name || 'Unknown Product',
    brand: product.brands || 'Unknown Brand',
    imageURL: mainImageURL,
    images: images,
    nutriments: {
      caloriesPer100g: n['energy-kcal_100g'] || 0,
      caloriesPer100g_unit: n['energy-kcal_unit'] || 'kcal',
      calories: n['energy-kcal'] || 0,
      calories_unit: n['energy-kcal_unit'] || 'kcal',
      fat: n['fat_100g'] || 0,
      fat_unit: n['fat_unit'] || 'g',
      saturatedFat: n['saturated-fat_100g'] || 0,
      saturatedFat_unit: n['saturated-fat_unit'] || 'g',
      carbohydrates: n['carbohydrates_100g'] || 0,
      carbohydrates_unit: n['carbohydrates_unit'] || 'g',
      sugars: n['sugars_100g'] || 0,
      sugars_unit: n['sugars_unit'] || 'g',
      fiber: n['fiber_100g'] || 0,
      fiber_unit: n['fiber_unit'] || 'g',
      proteins: n['proteins_100g'] || 0,
      proteins_unit: n['proteins_unit'] || 'g',
      salt: n['salt_100g'] || 0,
      salt_unit: n['salt_unit'] || 'g',
      sodium: n['sodium_100g'] || 0,
      sodium_unit: n['sodium_unit'] || 'g',
    },
    additivesCount: filteredAdditives.length,
    additives: filteredAdditives,
    isOrganic: isOrganic,
    isHalal: isHalal,
    isVegan: isVegan,
    quantity: product.quantity || 'unknown',
    barcode: product.code || barcode,
    category: categoryConfig.id,
    pnnsTag: pnns2Tag || pnns1Tag,
    pnnsGroup1Tag: pnns1Tag,
    ppiGroups: {
      pnns_groups_1: product.pnns_groups_1 || null,
      pnns_groups_2: product.pnns_groups_2 || null,
    },
    scores: {
      nutrition: {
        ...nutritionScore,
        breakdown: {
          sugar: nutritionScore.points.sugar,
          saturatedFat: nutritionScore.points.saturatedFat,
          salt: nutritionScore.points.salt,
          fiber: nutritionScore.points.fiber,
          protein: nutritionScore.points.protein,
        }
      },
      additives: additiveScore,
      organic: organicScore,
      final: {
        outOf10: finalScoreOutOf10,
        outOf100: Number(finalScoreOutOf100.toFixed(2))
      }
    }
  };
}

function enrichAdditives(items) {
  const { byName } = loadAdditivesData();
  return items.map(item => {
    const enrichedAdditives = [];
    if (item.additives && Array.isArray(item.additives)) {
      for (const additiveName of item.additives) {
        const fullAdditive = byName.get(additiveName);
        if (fullAdditive) {
          enrichedAdditives.push(fullAdditive);
        }
      }
    }
    return { ...item, additives: enrichedAdditives };
  });
}

const productServices = {
 async getProductData(barcode, userId = null) {
    try {
      const formattedCacheKey = `formatted:${barcode}`;
      let formattedProduct = productCache.get(formattedCacheKey);
      if (formattedProduct) {
        const { ...product } = formattedProduct;
        formattedProduct = product;
      } else {
        const productData = await getProduct(barcode);

        if (!productData || !productData.product) {
          throw createError(404, `Product with barcode ${barcode} not found`);
        }

        if (process.env.NODE_ENV === 'testing') {
          const publicDir = path.join(__dirname, '..', '..', 'public');
          if (!fs.existsSync(publicDir)) {
            fs.mkdirSync(publicDir, { recursive: true });
          }
          fs.writeFileSync(
            path.join(publicDir, `${barcode}.json`),
            JSON.stringify(productData, null, 2)
          );
        }

        const product = productData.product;
        formattedProduct = formatProduct(product, barcode);

        productCache.set(formattedCacheKey, formattedProduct);
      }

      const additiveNames = formattedProduct.additives.map(additive => additive.name || '').filter(name => name);

      if (userId) {
        const historyData = {
          userId: userId,
          productName: formattedProduct.productName,
          brand: formattedProduct.brand,
          imageURL: formattedProduct.imageURL,
          calories: formattedProduct.nutriments.caloriesPer100g,
          saturatedFat: formattedProduct.nutriments.saturatedFat,
          sugars: formattedProduct.nutriments.sugars,
          fiber: formattedProduct.nutriments.fiber,
          proteins: formattedProduct.nutriments.proteins,
          salt: formattedProduct.nutriments.salt,
          additivesCount: formattedProduct.additivesCount,
          additives: additiveNames,
          isOrganic: formattedProduct.isOrganic,
          isHalal: formattedProduct.isHalal,
          isVegan: formattedProduct.isVegan,
          quantity: formattedProduct.quantity,
          barcode: formattedProduct.barcode,
          finalScore: formattedProduct.scores.final.outOf10,
        };

        Promise.all([
          prisma.history.create({ data: historyData }),
          prisma.user.findUnique({
            where: { id: userId },
            select: { streak: true, lastStreakDate: true }
          })
        ]).then(async ([, user]) => {
          if (user) {
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            const lastStreakDate = user.lastStreakDate ? new Date(user.lastStreakDate) : null;
            if (lastStreakDate) {
              lastStreakDate.setHours(0, 0, 0, 0);
            }

            let newStreak = user.streak || 0;
            const daysDifference = lastStreakDate
              ? Math.floor((today - lastStreakDate) / (1000 * 60 * 60 * 24))
              : null;

            if (!lastStreakDate) {
              newStreak = 1;
            } else if (daysDifference === 1) {
              newStreak = (user.streak || 0) + 1;
            } else if (daysDifference === 0) {
              newStreak = user.streak || 0;
            } else {
              newStreak = 1;
            }

            await prisma.user.update({
              where: { id: userId },
              data: { streak: newStreak, lastStreakDate: today }
            });
          }
        }).catch(() => {});
      }

      return {
        ...formattedProduct,
        comparedToCategory: formattedProduct.pnnsTag || null,
        comparedToCategoryFallback: formattedProduct.pnnsGroup1Tag || null,
      };
    } catch (error) {
      if (error.status === 404 || error.statusCode === 404) {
        throw error;
      }

      if (typeof error?.message === 'string' && error.message.toLowerCase().includes('not found')) {
        throw createError(404, `Product with barcode ${barcode} not found`);
      }

      throw createError(500, `Error fetching product: ${error.message || 'Unknown error'}`);
    }
  },

  async getProductAlternatives(barcode, comparedToCategory, score, fallbackCategory = null) {
    try {
      const currentScoreOutOf100 = score * 10;
      console.log(`[Alternatives] Request: barcode=${barcode}, pnns2="${comparedToCategory}", fallback="${fallbackCategory}", currentScore=${score} (outOf100: ${currentScoreOutOf100})`);

      if (!comparedToCategory && !fallbackCategory) {
        console.log(`[Alternatives] No category provided, returning empty`);
        return { alternatives: [] };
      }

      let alternativesData = { products: [] };

      if (comparedToCategory) {
        alternativesData = await fetchAlternativesByPnns2(comparedToCategory, barcode, 10);
        console.log(`[Alternatives] Fetched ${alternativesData.products?.length || 0} products for pnns2 "${comparedToCategory}"`);
      }

      let quickScored = scoreAndFilter(alternativesData.products, currentScoreOutOf100);

      if (quickScored.length === 0 && fallbackCategory) {
        console.log(`[Alternatives] No good pnns2 results, falling back to pnns1 "${fallbackCategory}"`);
        alternativesData = await fetchAlternativesByPnns(fallbackCategory, barcode, 10);
        console.log(`[Alternatives] Fetched ${alternativesData.products?.length || 0} products for pnns1 "${fallbackCategory}"`);
        quickScored = scoreAndFilter(alternativesData.products, currentScoreOutOf100);
      }

      console.log(`[Alternatives] ${quickScored.length} products scored higher than ${currentScoreOutOf100}`);

      const scoredAlternatives = quickScored
        .map(({ rawProduct }) => {
          try {
            const altBarcode = rawProduct.code || rawProduct._id;
            return formatProduct(rawProduct, altBarcode);
          } catch (error) {
            console.log(`[Alternatives] Error formatting product: ${error.message}`);
            return null;
          }
        })
        .filter(Boolean);

      console.log(`[Alternatives] Returning ${scoredAlternatives.length} alternatives`);
      return { alternatives: scoredAlternatives };
    } catch (error) {
      console.log(`[Alternatives] Error: ${error.message}`);
      return { alternatives: [] };
    }
  },

  async searchProducts(searchTerm, options = {}) {
    try {
      const page = Math.max(parseInt(options.page || '1', 10), 1);
      const pageSize = Math.max(parseInt(options.limit || '5', 10), 1);

      if (!searchTerm || searchTerm.trim().length === 0) {
        throw createError(400, 'Search term is required');
      }

      const trimmedTerm = searchTerm.trim();
      const formattedCacheKey = `search:formatted:${trimmedTerm.toLowerCase()}:${page}:${pageSize}`;
      const cachedResult = searchCache.get(formattedCacheKey);
      if (cachedResult) return cachedResult;

      const searchData = await fetchProductSearch(trimmedTerm, page, pageSize);

      if (!searchData.products || !Array.isArray(searchData.products)) {
        return {
          items: [],
          page,
          limit: pageSize,
          total: 0,
          totalPages: 0,
          searchTerm: trimmedTerm
        };
      }

      const formattedProducts = [];

      for (const product of searchData.products) {
        try {
          if (!product.code && !product._id) continue;

          const barcode = product.code || product._id;
          const formattedProduct = formatProduct(product, barcode);
          formattedProducts.push(formattedProduct);
        } catch (productError) {}
      }

      const result = {
        items: formattedProducts,
        page,
        limit: pageSize,
        total: searchData.count || 0,
        totalPages: Math.ceil((searchData.count || 0) / pageSize),
        searchTerm: trimmedTerm
      };

      searchCache.set(formattedCacheKey, result);
      return result;
    } catch (error) {
      if (error.status === 400 || error.statusCode === 400) {
        throw error;
      }

      throw createError(500, `Error searching products: ${error.message || 'Unknown error'}`);
    }
  },

  async getMyHistory(userId, options = {}) {
    const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);
    if (!resolvedUserId) {
      throw createError(401, 'Authentication required');
    }

    const page = Math.max(parseInt(options.page || '1', 10), 1);
    const limit = Math.max(parseInt(options.limit || '10', 10), 1);
    const search = (options.search || '').toString().trim();

    const where = { userId: resolvedUserId };

    if (search) {
      where.OR = [
        { productName: { contains: search, mode: 'insensitive' } },
        { brand: { contains: search, mode: 'insensitive' } },
        { barcode: { contains: search, mode: 'insensitive' } },
      ];
    }

    let total = 0;
    let items = [];

    try {
      const [dbItems, dbTotal] = await Promise.all([
        prisma.history.findMany({
          where,
          orderBy: { createdAt: 'desc' },
          skip: (page - 1) * limit,
          take: limit,
        }),
        prisma.history.count({ where }),
      ]);

      total = dbTotal;

      items = dbItems
        .filter(item => item.productName != null)
        .map(item => ({
          id: item.id || '',
          productName: item.productName || 'Unknown Product',
          brand: item.brand || 'Unknown Brand',
          imageURL: item.imageURL || '',
          calories: item.calories || 0,
          saturatedFat: item.saturatedFat || 0,
          sugars: item.sugars || 0,
          fiber: item.fiber || 0,
          proteins: item.proteins || 0,
          salt: item.salt || 0,
          additivesCount: item.additivesCount || 0,
          additives: item.additives || [],
          isOrganic: item.isOrganic || false,
          isHalal: item.isHalal || false,
          isVegan: item.isVegan ?? null,
          quantity: item.quantity || 'unknown',
          barcode: item.barcode || '',
          finalScore: item.finalScore || 0,
          createdAt: item.createdAt,
        }));
    } catch (error) {
      total = 0;
      items = [];
    }

    const enrichedItems = enrichAdditives(items);

    return {
      items: enrichedItems,
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
    };
  },

  async deleteMyHistory(userId, historyId) {
    const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);
    if (!resolvedUserId) {
      throw createError(401, 'Authentication required');
    }

    const item = await prisma.history.findUnique({ where: { id: historyId } });
    if (!item || item.userId !== resolvedUserId) {
      throw createError(404, 'History item not found or you do not have permission to delete it');
    }

    await prisma.history.delete({ where: { id: historyId } });
    return { success: true, message: 'History item deleted successfully' };
  },

  async deleteAllMyHistory(userId) {
    const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);
    if (!resolvedUserId) {
      throw createError(401, 'Authentication required');
    }

    const historyCount = await prisma.history.count({
      where: { userId: resolvedUserId }
    });

    await prisma.history.deleteMany({
      where: { userId: resolvedUserId }
    });

    return {
      success: true,
      message: 'All history deleted successfully',
      deletedCount: historyCount
    };
  },

  async getMyCart(userId) {
    const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);
    if (!resolvedUserId) {
      throw createError(401, 'Authentication required');
    }

    let userCart = await prisma.cart.findUnique({
      where: { userId: resolvedUserId },
      include: {
        cartItems: {
          orderBy: { createdAt: 'desc' }
        }
      }
    });

    if (!userCart) {
      userCart = await prisma.cart.create({
        data: {
          userId: resolvedUserId,
        },
        include: {
          cartItems: true
        }
      });
    }

    const enrichedItems = enrichAdditives(userCart.cartItems);

    return {
      cartId: userCart.id,
      items: enrichedItems,
      itemsCount: enrichedItems.length,
      createdAt: userCart.createdAt,
      updatedAt: userCart.updatedAt,
    };
  },

  async addToCart(userId, productData) {
    const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);
    if (!resolvedUserId) {
      throw createError(401, 'Authentication required');
    }

    let userCart = await prisma.cart.findUnique({
      where: { userId: resolvedUserId },
      include: {
        cartItems: true
      }
    });

    if (!userCart) {
      userCart = await prisma.cart.create({
        data: {
          userId: resolvedUserId,
        },
        include: {
          cartItems: true
        }
      });
    }

    const existingItem = userCart.cartItems.find(item => item.barcode === productData.barcode);
    if (existingItem) {
      throw createError(409, 'Product already exists in cart');
    }

    const additiveNames = (productData.additives || []).map(additive =>
      typeof additive === 'string' ? additive : (additive.name || '')
    ).filter(name => name);

    const cartItem = await prisma.cartItem.create({
      data: {
        cartId: userCart.id,
        productName: productData.productName,
        brand: productData.brand,
        imageURL: productData.imageURL,
        calories: productData.nutriments?.caloriesPer100g || 0,
        saturatedFat: productData.nutriments?.saturatedFat || 0,
        sugars: productData.nutriments?.sugars || 0,
        fiber: productData.nutriments?.fiber || 0,
        proteins: productData.nutriments?.proteins || 0,
        salt: productData.nutriments?.salt || 0,
        additivesCount: productData.additivesCount || 0,
        additives: additiveNames,
        isOrganic: productData.isOrganic || false,
        isHalal: productData.isHalal || false,
        isVegan: productData.isVegan ?? null,
        quantity: productData.quantity || 'unknown',
        barcode: productData.barcode,
        finalScore: productData.scores?.final?.outOf10 || 0,
      }
    });

    return {
      success: true,
      message: 'Product added to cart successfully',
      cartItem: {
        ...cartItem,
        additives: productData.additives || [],
      }
    };
  },

  async deleteFromCart(userId, cartItemId) {
    const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);
    if (!resolvedUserId) {
      throw createError(401, 'Authentication required');
    }

    const cartItem = await prisma.cartItem.findUnique({
      where: { id: cartItemId },
      include: {
        cart: true
      }
    });

    if (!cartItem) {
      throw createError(404, 'Cart item not found');
    }

    if (cartItem.cart.userId !== resolvedUserId) {
      throw createError(403, 'You do not have permission to delete this cart item');
    }

    await prisma.cartItem.delete({
      where: { id: cartItemId }
    });

    return {
      success: true,
      message: 'Item removed from cart successfully'
    };
  },

  async deleteCompleteCart(userId) {
    const resolvedUserId = typeof userId === 'string' ? userId : (userId?.user || userId?.id || userId?.userId || null);
    if (!resolvedUserId) {
      throw createError(401, 'Authentication required');
    }

    const userCart = await prisma.cart.findUnique({
      where: { userId: resolvedUserId },
      include: {
        cartItems: true
      }
    });

    if (!userCart) {
      throw createError(404, 'Cart not found');
    }

    await prisma.cartItem.deleteMany({
      where: { cartId: userCart.id }
    });

    return {
      success: true,
      message: 'Cart cleared successfully',
      deletedItemsCount: userCart.cartItems.length
    };
  },
}

export default productServices;
