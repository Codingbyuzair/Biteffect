class MemoryCache {
  constructor(options = {}) {
    this.cache = new Map();
    this.defaultTTL = options.defaultTTL || 60 * 60 * 1000;
    this.maxEntries = options.maxEntries || 500;

    this.cleanupInterval = setInterval(() => this.cleanup(), 5 * 60 * 1000);
    if (this.cleanupInterval.unref) this.cleanupInterval.unref();
  }

  get(key) {
    const entry = this.cache.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      this.cache.delete(key);
      return null;
    }
    return entry.value;
  }

  set(key, value, ttl) {
    if (this.cache.size >= this.maxEntries && !this.cache.has(key)) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
    this.cache.set(key, {
      value,
      expiresAt: Date.now() + (ttl || this.defaultTTL),
    });
  }

  cleanup() {
    const now = Date.now();
    for (const [key, entry] of this.cache) {
      if (now > entry.expiresAt) {
        this.cache.delete(key);
      }
    }
  }
}

export const productCache = new MemoryCache({
  defaultTTL: 2 * 60 * 60 * 1000,
  maxEntries: 1000,
});

export const searchCache = new MemoryCache({
  defaultTTL: 15 * 60 * 1000,
  maxEntries: 200,
});

export const alternativesCache = new MemoryCache({
  defaultTTL: 30 * 60 * 1000,
  maxEntries: 200,
});


//     Pannelty 
// no found products
// compare to categpry 
// cigrites 0 points 
// fix 0.01 points to 1 in protien
// reomve ppoints from search