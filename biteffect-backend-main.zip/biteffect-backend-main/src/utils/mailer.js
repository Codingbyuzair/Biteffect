import nodemailer from "nodemailer"
import dotenv from "dotenv"

dotenv.config();
let transporter = null;

export const createTransporter = () => {
  console.log(process.env.SMTP_HOST,  process.env.SMTP_PORT, process.env.SMTP_USERNAME, process.env.SMTP_PASSWORD);
  if (!transporter) {
    transporter = nodemailer.createTransport({
      port: Number(process.env.SMTP_PORT),
      secure: Number(process.env.SMTP_PORT) === 465,
      host: process.env.SMTP_HOST,
      auth: {
        user: process.env.SMTP_USERNAME, 
        pass: process.env.SMTP_PASSWORD 
      }
    });
  }
  return transporter;
};