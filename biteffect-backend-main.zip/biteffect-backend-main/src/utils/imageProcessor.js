export function collectProductImages(product) {
  const images = [];

  if (product.image_url) images.push(product.image_url);
  if (product.image_front_url && product.image_front_url !== product.image_url) {
    images.push(product.image_front_url);
  }

  if (product.image_ingredients_url) images.push(product.image_ingredients_url);
  if (product.image_nutrition_url) images.push(product.image_nutrition_url);
  if (product.image_packaging_url) images.push(product.image_packaging_url);

  return [...new Set(images)].filter(url => url && url.trim());
}
